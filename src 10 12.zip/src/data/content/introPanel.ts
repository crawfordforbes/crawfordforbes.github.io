type IntroPanelContentType = {
  title?: string,
  descriptionHTML?: string,
}

export const introPanelContent:IntroPanelContentType = {
  title: "I build polished, data-driven web apps and lead small teams from concept to production."
}