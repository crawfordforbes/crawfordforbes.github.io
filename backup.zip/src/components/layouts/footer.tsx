import './styles/footer.css'

function Footer() {

  return (
    <footer className="footer">
      <div className="temp-space"></div>
    </footer>
  )
}

export default Footer
