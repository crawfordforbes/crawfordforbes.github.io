export const introPanelContent = {
  title: "I build polished, data-driven web apps and lead small teams from concept to production."
}