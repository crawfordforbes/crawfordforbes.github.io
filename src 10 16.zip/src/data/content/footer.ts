export const footerContent = {
  description: "Lead Web Developer focused on front-end apps, mentoring teams, and skill building. Also a musician and composer.",
}